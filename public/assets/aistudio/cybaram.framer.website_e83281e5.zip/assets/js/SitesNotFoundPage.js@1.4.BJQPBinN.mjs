import{t as e}from"./rolldown-runtime.Bi-D_2cA.mjs";import{l as t,o as n,s as r,w as i,y as a}from"./react.Dlpel5Rf.mjs";import{H as o,ft as s}from"./framer.DmhH0sL2.mjs";var c,l,u,d=e((()=>{r(),i(),o(),c=()=>(a(()=>{let e=document.querySelector(`meta[name="robots"]`);e?e.setAttribute(`content`,`noindex`):(e=document.createElement(`meta`),e.setAttribute(`name`,`robots`),e.setAttribute(`content`,`noindex`),document.head.appendChild(e))},[]),n(`div`,{className:`__framer-not-found-page`,style:{display:`flex`,height:`100vh`,alignItems:`center`,justifyContent:`center`,backgroundColor:`var(--color-primary)`,background:`var(--color-background)`,fontSize:`var(--font-size-body)`,boxSizing:`border-box`,fontFeatureSettings:`"liga", "clig"`,fontVariantLigatures:`common-ligatures`,textRendering:`optimizeLegibility`},children:t(`main`,{style:{boxSizing:`border-box`,fontFamily:`"Inter", sans-serif`,fontWeight:500,maxWidth:`240px`,width:`100%`,display:`flex`,alignItems:`center`,flexDirection:`column`,padding:`0 20px`,textWrap:`balance`},children:[n(`svg`,{xmlns:`http://www.w3.org/2000/svg`,width:`14`,height:`21`,style:{verticalAlign:`middle`,color:`var(--color-primary)`,marginBottom:`20px`},children:n(`path`,{d:`M 14 0 L 14 7 L 7 7 L 0 0 Z M 14 14 L 7 14 L 7 21 L 0 14 L 0 7 L 7 7 Z`,fill:`currentColor`})}),n(`h1`,{style:{margin:`0 0 10px 0`,fontSize:`var(--font-size-title)`,color:`var(--color-primary)`,textAlign:`center`},children:`Page Not Found`}),n(`div`,{style:{color:`var(--color-secondary)`,marginBottom:`20px`,lineHeight:`1.5em`,textAlign:`center`},children:`The page you are looking for does not exist or may have been moved.`}),n(`a`,{href:`/`,role:`button`,style:{backgroundColor:`var(--color-tint)`,color:`#ffffff`,paddingLeft:`8px`,paddingRight:`8px`,borderRadius:`8px`,lineHeight:`30px`,height:`30px`,textDecoration:`none`,verticalAlign:`baseline`},children:`Back to Home`})]})})),l=s(c,[`@font-face {
      font-family: Inter;
      src: url(assets/fonts/inter-semibold-1.woff2);
      font-display: swap;
      font-style: normal;
      font-weight: 600;
      unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F,
        U+FE2E-FE2F;
    }`,`@font-face {
      font-family: Inter;
      src: url(assets/fonts/inter-semibold-2.woff2);
      font-display: swap;
      font-style: normal;
      font-weight: 600;
      unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
    }`,`@font-face {
      font-family: Inter;
      src: url(assets/fonts/inter-semibold-3.woff2);
      font-display: swap;
      font-style: normal;
      font-weight: 600;
      unicode-range: U+1F00-1FFF;
    }`,`@font-face {
      font-family: Inter;
      src: url(assets/fonts/inter-semibold-4.woff2);
      font-display: swap;
      font-style: normal;
      font-weight: 600;
      unicode-range: U+0370-03FF;
    }`,`@font-face {
      font-family: Inter;
      src: url(assets/fonts/inter-semibold-5.woff2);
      font-display: swap;
      font-style: normal;
      font-weight: 600;
      unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB,
        U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
    }`,`@font-face {
      font-family: Inter;
      src: url(https://framerusercontent.com/assets/1ZFS7N918ojhhd0nQWdj3jz4w.woff2);
      font-display: swap;
      font-style: normal;
      font-weight: 600;
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
        U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193,
        U+2212, U+2215, U+FEFF, U+FFFD;
    }`,`@font-face {
      font-family: Inter;
      src: url(assets/fonts/inter-semibold-7.woff2);
      font-display: swap;
      font-style: normal;
      font-weight: 600;
      unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169,
        U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
    }`,`@font-face {
      font-family: Inter;
      src: url(assets/fonts/inter-medium-1.woff2);
      font-display: swap;
      font-style: normal;
      font-weight: 500;
      unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F,
        U+FE2E-FE2F;
    }`,`@font-face {
      font-family: Inter;
      src: url(assets/fonts/inter-medium-2.woff2);
      font-display: swap;
      font-style: normal;
      font-weight: 500;
      unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
    }`,`@font-face {
      font-family: Inter;
      src: url(assets/fonts/inter-medium-3.woff2);
      font-display: swap;
      font-style: normal;
      font-weight: 500;
      unicode-range: U+1F00-1FFF;
    }`,`@font-face {
      font-family: Inter;
      src: url(assets/fonts/inter-medium-4.woff2);
      font-display: swap;
      font-style: normal;
      font-weight: 500;
      unicode-range: U+0370-03FF;
    }`,`@font-face {
      font-family: Inter;
      src: url(assets/fonts/inter-medium-5.woff2);
      font-display: swap;
      font-style: normal;
      font-weight: 500;
      unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB,
        U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
    }`,`@font-face {
      font-family: Inter;
      src: url(https://framerusercontent.com/assets/d3tHnaQIAeqiE5hGcRw4mmgWYU.woff2);
      font-display: swap;
      font-style: normal;
      font-weight: 500;
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
        U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193,
        U+2212, U+2215, U+FEFF, U+FFFD;
    }`,`@font-face {
      font-family: Inter;
      src: url(assets/fonts/inter-medium-7.woff2);
      font-display: swap;
      font-style: normal;
      font-weight: 500;
      unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169,
        U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
    }`,`@font-face {
      font-family: Inter Placeholder;
      src: local("Arial");
      ascent-override: 89.79%;
      descent-override: 22.36%;
      line-gap-override: 0%;
      size-adjust: 107.89%;
    }`,`.__framer-not-found-page {
      --color-background: #ffffff;
      --color-primary: #333;
      --color-secondary: #888;
      --color-tint: #0099ff;
      --font-size-body: 12px;
      --font-size-title: 12px;
    }`,`@media (prefers-color-scheme: dark) {
      .__framer-not-found-page {
        --color-background: #000000;
        --color-primary: #fff;
        --color-secondary: #888;
      }
    }`]),u={exports:{default:{type:`reactComponent`,name:`component`,slots:[],annotations:{framerContractVersion:`1`}},__FramerMetadata__:{type:`variable`}}}}));e((()=>{d(),d()}))();export{u as __FramerMetadata__,l as default};
//# sourceMappingURL=SitesNotFoundPage.js@1.4.BJQPBinN.mjs.map